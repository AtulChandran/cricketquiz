<?php
session_start();
?>

<?php 
require 'config.php';
global $conn;
$sql="select user_name,score,wicket from users order by score desc";
$result = mysqli_query($con,$sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "name: " . $row["user_name"]. " - Score: " . $row["score"]. " " . "/".$row["wicket"].  "<br>";
		
    }
} else {
    echo "0 results";
}
?>