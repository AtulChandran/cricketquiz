<?php
session_start();
?>

<?php 
require 'config.php';
global $conn;
$sql="select user_name,score,wicket from users order by score desc";

$result = mysqli_query($con,$sql);
if ($result->num_rows > 0) {
	echo "<table border='10' style='border:10px solid black; margin:auto;' width='1000' height='150'><tr style='text-align:center;'><td style='text-transform:uppercase; font-size:50px; color:red; border-bottom:4px solid black; '>Name</td><td style='text-transform:uppercase; font-size:50px; color:red; border-bottom:4px solid black;'>Score</td></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
    	if($row["wicket"]!=0){
        echo "<tr style='text-align:center'><td style='font-size:30px;'>". $row["user_name"]. "</td><td style='font-size:30px'>". $row["score"]. " " . "/".$row["wicket"].  "</td></tr>";
    }
    else{
    	 echo "<tr style='text-align:center'><td style='font-size:30px'>". $row["user_name"]. "</td><td style='font-size:30px'>". $row["score"]. " " . "".$row["wicket"].  "</td></tr>";	
    }
		
    }
    echo "</table>";
   }
 else {
    echo "0 results";
}
?>