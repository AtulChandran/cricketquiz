<?php
session_start();

?>


<?php 
require 'config.php';
global $con;
global $con1;
global $final_res;
if(!empty( $_SESSION['name'] && !empty( $_POST ) )){
    
    $sixes=0;
	$fours=0;
    $wrong_answer=0;
    $unanswered=0;
    $final_res=0;
	$wickets=0;	
     
   $keys = array_keys( $_POST );
   $order = join(",", $keys );
   
   
   $response = mysqli_query($con, "select id,answer from questions where id IN($order) ORDER BY FIELD(id,$order)")   or die(mysqli_error($con));
   
   while($result=mysqli_fetch_assoc($response)){
       if($result['answer']==$_POST[$result['id']]){
               $sixes++;
			   $final_res=$sixes*6;
           }else if($_POST[$result['id']]==5){
               $unanswered++;
           }
           else{
               $wrong_answer++;
           }
   }
   $name = $_SESSION['name'];  
   
   mysqli_query($con, "update users set score='$final_res' where user_name='$name'");
   mysqli_query($con, "update level set score='$final_res' where user_name='$name'");
   mysqli_query($con, "update level set level_name='Level 2' where user_name='$name'");
	
?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="css/style.css" rel="stylesheet" media="screen">
        

    </head>
    <body>
	<style>
	@font-face {
					font-family: myFirstFont;
					src: url(digital-7.ttf);
			}
	p{
	color:#000;
	font-size:30px;
	text-align:center;
	position: 200px;
	font-family: myFirstFont;
   
   src: url(digital-7.ttf);
   url(digital-7.ttf);
	} 
a{
	color:#000;
	font-size:20px;
	background:url('images.jpg');
	text-align:center;
	font-family: myFirstFont;
   
   src: url(digital-7.ttf);
   url(digital-7.ttf);
	} 	
	</style>
        <header>
            <p class="text-center">
                Welcome <?php 
                if(!empty($_SESSION['name'])){
                    echo $_SESSION['name'];
                }?>
               
            </p>
        </header>
        <div class="container result">
            <div class="row"> 
                        
           </div>  
           <hr>   
           <div class="row"> 
                  <div class="col-xs-18 col-sm-9 col-lg-9"> 
                    
                  </div>
                  
                  <div class="col-xs-6 col-sm-3 col-lg-3"> 
                     <!--<a href="<?php echo BASE_PATH.'questions.php';?>" class='btn btn-success'>Start new Quiz!!!</a>              -->    
                     <!--<a href="<?php echo BASE_PATH.'logout.php';?>" class='btn btn-success'>Logout</a>-->
                   
                       <div style="margin-top: 30%">
					   						<?php $wickets=$wrong_answer+$unanswered;?>

					   	<?php mysqli_query($con, "INSERT INTO score (user_name,level_name,score,fours,sixes,wickets) VALUES ('$name','Level 2','$final_res','$fours','$sixes','$wickets')") or die(mysqli_error( $con ));?>						
<?php													  $wicket=mysqli_query($con,"select sum(wickets) from score where user_name='$name'");?>

				<?php				$finalwicket = mysqli_fetch_row($wicket);?>
				<?php if($finalwicket[0]>=5){?>
							<?php header( "Location: wicket.html ") ;?>
						<?php }?>

					   <?php $six=mysqli_query($con,"select sum(sixes) from score where user_name='$name'");
					   $finalsix = mysqli_fetch_row($six);?>
                        <p>Sixes : <span class="answer"><?php echo "$finalsix[0]";?></span></p>
                        <!--<p>Total no. of wrong answers : <span class="answer"><?php echo $wrong_answer;?></span></p>-->
                        <!--<p>Fours : <span class="answer"><?php echo $fours;?></span></p>-->
						
						<?php $result=mysqli_query($con,"select sum(score) from score where user_name='$name'");
							  
							  
							  
							$finalscore = mysqli_fetch_row($result);
							
								
								
								?>

						<p>Score is : <span class="answer"><?php echo "$finalscore[0]/$finalwicket[0]"; ?></span></p>
													<?php mysqli_query($con, "INSERT INTO result (sixes,fours,wickets,tot_score) VALUES ('$sixes',0,'$wickets','$final_res')") or die(mysqli_error( $con ));?>		
<?php  mysqli_query($con, "update users set score='$finalscore[0]' where user_name='$name'");?>                       
<?php  mysqli_query($con, "update users set wicket='$finalwicket[0]' where user_name='$name'");?>

</div> 
                   <?php if($sixes>=3){?>
								
								<p>You entered level 3</p>
								 <a href="<?php echo BASE_PATH.'questions3.php';?>" class='btn btn-success'>Enter Level 3!!!</a>                   

								<form class="form-level2" method="post" id='level2' name="level2" action="questions3.php">
							<div class="form-group">
							<?php mysqli_query($con, "update level set level_name='Level 3' where user_name='$name'");?>
							<?php mysqli_query($con, "update score set level_name='Level 3' where user_name='$name'");?>

								<span class="help-block"></span>
							</div>
							
							<br>
							
						</form>
							<?php }	else{ ?>
								<p>Better luck next time</p>
															<?php mysqli_query($con, "update score set level_name='Level 2' where user_name='$name'");?>

						<?php }?>
                   </div>
                    
            </div>    
            
        </div>
        
        <script src="js/jquery-1.10.2.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <script src="js/jquery.validate.min.js"></script>

        

    </body>
</html>
<?php }else{
    
 header( 'Location: '.BASE_PATH ) ;
      
}?>