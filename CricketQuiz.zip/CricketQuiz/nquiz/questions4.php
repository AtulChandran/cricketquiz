<?php
session_start();
?>


<?php 
require 'config.php';
global $con;
global $con1;
 if( isset( $_POST['name'] ) && !empty($_POST['name'])){
     $name = $_POST['name'];
	 $mail=$_POST['MailAddress'];
 
	 
     mysqli_query($con, "INSERT INTO users (id, user_name,user_mail_id,score) VALUES (id,'$name','$mail',0)") or die(mysqli_error( $con ));
	 mysqli_query($con, "INSERT INTO level (user_name,level_name,id,score) VALUES ('$name','Level 4',id,0)") or die(mysqli_error( $con ));

     $_SESSION['name']= $name;
	 $_SESSION['mail']=$mail;
     $_SESSION['id'] = mysqli_insert_id($con);
	 
 }
if( !empty( $_SESSION['name'] ) ){
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Cricket Quiz</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
		<link href="css/style.css" rel="stylesheet" media="screen">
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="../../assets/js/html5shiv.js"></script>
		<script src="../../assets/js/respond.min.js"></script>
		<![endif]-->
		<style>
			.container {
				margin-top: 110px;
			}
			.error {
				color: #B94A48;
			}
			@font-face {
					font-family: myFirstFont;
					src: url(digital-7.ttf);
			}
			@font-face {
				font-family: myFirstFont1;
			src: url(pdark.ttf);
			}
header{
	background-image:url('images.jpg');
	background-repeat:no-repeat;
	height: 70px;
	color:#f00;
	font-size:35px;
	font-family: myFirstFont1;
   
   src: url(pdark.ttf);
   url(pdark.ttf);
}
p{
	color:#000;
	font-size:30px;
	font-family: myFirstFont;
   
   src: url(digital-7.ttf);
   url(digital-7.ttf);
			.form-horizontal {
				margin-bottom: 0px;
			}
			.hide{display: none;}
}
input,select{
	color:#000;
	font-size:30px;
	font-family: myFirstFont;
   
   src: url(digital-7.ttf);
   url(digital-7.ttf);
			.form-horizontal {
				margin-bottom: 0px;
			}
			.hide{display: none;}	
}		
		</style>
	</head>
	<body background="1000.jpg">
	    <header>
            <p class="text-center">
                Welcome : <?php if(!empty($_SESSION['name'])){echo $_SESSION['name'];}?>
            </p>
        </header>
        
		<div class="container question">
			<div class="col-xs-12 col-sm-8 col-md-8 col-xs-offset-4 col-sm-offset-3 col-md-offset-3">
				<p>
					Level 4
				</p>
				<?php 
				$name = $_SESSION['name'];
				$score=mysqli_query($con,"select score,wicket from users where user_name='$name'");
				$levelscore = mysqli_fetch_row($score);?>
				
				
				<p>Score till level 1  : <span class="answer"><?php echo "$levelscore[0]/$levelscore[1]"; ?></span></p>
				<hr>
				<form class="form-horizontal" role="form" id='login' method="post" action="finish.php">
					<?php 
					$res = mysqli_query($con, "select * from questions where id between 17 and 22 ORDER BY rand() limit 5") or die(mysqli_error( $con ));
                    $rows = mysqli_num_rows( $res );
					$i=1;
                while( $result = mysqli_fetch_assoc( $res ) ){?>
                    
                    
                    <?php if($i==1){?>         
                    <div id='question<?php echo $i;?>' class='cont'>
                    <p class='questions' id="qname<?php echo $i;?>"> <?php echo $i?>.<?php echo $result['question_name'];?></p>
                    <input type="radio" value="1" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer1'];?>
                   <br/>
                    <input type="radio" value="2" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer2'];?>
                    <br/>
                    <input type="radio" value="3" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer3'];?>
                    <br/>
                    <input type="radio" value="4" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer4'];?>
                    <br/>
                    <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>                                                                      
                    <br/>
                    <button id='<?php echo $i;?>' class='next btn btn-success' type='button'>Next</button>
                    </div>     
                      
                     <?php }elseif($i<1 || $i<$rows){?>
                     
                       <div id='question<?php echo $i;?>' class='cont'>
                    <p class='questions' id="qname<?php echo $i;?>"><?php echo $i?>.<?php echo $result['question_name'];?></p>
                    <input type="radio" value="1" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer1'];?>
                    <br/>
                    <input type="radio" value="2" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer2'];?>
                    <br/>
                    <input type="radio" value="3" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer3'];?>
                    <br/>
                    <input type="radio" value="4" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer4'];?>
                    <br/>
                    <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>                                                                      
                    <br/>
                                        
                    <button id='<?php echo $i;?>' class='next btn btn-success' type='button' >Next</button>
                    </div>
                       
                       
                       
                        
                        
                   <?php }elseif($i==$rows){?>
                    <div id='question<?php echo $i;?>' class='cont'>
                    <p class='questions' id="qname<?php echo $i;?>"><?php echo $i?>.<?php echo $result['question_name'];?></p>
                    <input type="radio" value="1" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer1'];?>
                    <br/>
                    <input type="radio" value="2" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer2'];?>
                    <br/>
                    <input type="radio" value="3" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer3'];?>
                    <br/>
                    <input type="radio" value="4" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/><?php echo $result['answer4'];?>
                    <br/>
                    <input type="radio" checked='checked' style='display:none' value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>                                                                      
                    <br/>
                    
                                        
                    <button id='<?php echo $i;?>' class='next btn btn-success' type='submit'>Finish</button>
                    </div>
					<?php } $i++;} ?>
					
				</form>
			</div>
		</div>
       


<?php

if(isset($_POST[1])){ 
   $keys=array_keys($_POST);
   $order=join(",",$keys);
   
   
   
   $response = mysqli_query($con, "select id,answer from questions where id IN($order) ORDER BY FIELD(id,$order)")   or die(mysqli_error( $con ));
   $right_answer = 0;
   $wrong_answer = 0;
   $unanswered = 0;
   while( $result = mysqli_fetch_assoc( $response ) ){
       if( $result['answer']==$_POST[$result['id']] ){
           $right_answer++;
	   } else if($_POST[$result['id']]==5){
		   $unanswered++;
	   } else{
		   $wrong_answer++;
	   }
       
   }
   
   
   echo "right_answer : ". $right_answer."<br>";
   echo "wrong_answer : ". $wrong_answer."<br>";
   echo "unanswered : ". $unanswered."<br>";
}
?>
		<script src="js/jquery-1.10.2.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.validate.min.js"></script>
		
		<script>
		$('.cont').addClass('hide');
		count=$('.questions').length;
		 $('#question'+1).removeClass('hide');
		 
		 $(document).on('click','.next',function(){
		     last=parseInt($(this).attr('id'));     
		     nex=last+1;
		     $('#question'+last).addClass('hide');
		     
		     $('#question'+nex).removeClass('hide');
		 });
		 
		 $(document).on('click','.previous',function(){
             last=parseInt($(this).attr('id'));     
             pre=last-1;
             $('#question'+last).addClass('hide');
             
             $('#question'+pre).removeClass('hide');
         });
         
         
         
		</script>
	</body>
</html>
<?php }else{
    
 header( 'Location: '.BASE_PATH ) ;
      
}
?>