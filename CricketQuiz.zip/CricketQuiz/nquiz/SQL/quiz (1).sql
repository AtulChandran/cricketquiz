-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2018 at 05:36 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `level`
--
-- Creation: Oct 30, 2018 at 03:21 PM
--

CREATE TABLE `level` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `level_name` varchar(20) NOT NULL,
  `score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`user_id`, `user_name`, `level_name`, `score`) VALUES
(1, 'haha', 'level_name', 0),
(2, 'boom', 'level_name', 0),
(3, 'hjjh', 'level_name', 0),
(4, 'hjjh', 'level_name', 0),
(5, 'ytggh', 'level_name', 0),
(6, 'ghgh', 'level_name', 0),
(7, 'fff', 'level_name', 0),
(8, 'jhjh', 'level_name', 0),
(9, 'hbjhj', 'level_name', 0),
(10, 'jhkjhk', 'Level 2', 18),
(11, 'jhjkj', 'level_name', 0),
(12, 'jhkjh', 'level_name', 0),
(13, 'jkhkjh', 'level_name', 0),
(14, 'gjhjjhk', 'level_name', 0),
(15, 'mkjhkj', 'Level 1', 6),
(16, 'ffdf', 'Level 1', 0),
(17, 'fnjjh', 'Level 1', 6),
(18, 'dddd', 'level_name', 0),
(19, ',mwkjk', 'level_name', 0),
(20, 'jkhjkKLJLKJ', 'level_name', 0),
(21, 'jhkjhk', 'Level 2', 18),
(22, 'djhkjh', 'Level 1', 6),
(23, 'djd', 'level_name', 0),
(24, 'dhjkhk', 'Level 1', 12),
(25, 'djkhjkh', 'level_name', 0),
(26, 'khlkhlkh', 'Level 2', 18),
(27, 'dhkjhk', 'Level 2', 24),
(28, 'dhkjhkj', 'level_name', 0),
(29, 'shjkjhk', 'Level 2', 30),
(30, 'djhkjhk', 'level_name', 0),
(31, 'djhkjh', 'Level 1', 6),
(32, 'fjlkjl', 'Level 1', 0),
(33, 'jhkjhk', 'Level 2', 18),
(34, 'dhkjhk', 'Level 2', 24),
(35, 'dkjk', 'level_name', 0),
(36, 'dkl', 'level_name', 0),
(37, 'kjjlkj', 'level_name', 0),
(38, 'sjlk', 'level_name', 0),
(39, 'dklk', 'Level 2', 18),
(40, 'dklk', 'Level 2', 18),
(41, 'hjkjhk', 'level_name', 0),
(42, 'slkjk', 'Level 1', 0),
(43, 'ekhjk', 'Level 1', 6),
(44, 'djhkj', 'Level 2', 18),
(45, 'hjkjhkj', 'Level 3', 30),
(46, 'atul', 'Level 3', 24),
(47, 'atul', 'Level 3', 24),
(48, 'moyes', 'Level 2', 6),
(49, 'moyes', 'Level 2', 6),
(50, 'moyes', 'Level 2', 6),
(51, 'atul chandran', 'Level 4', 30),
(52, 'Rohit', 'Level 4 success', 18),
(53, 'dkljkl', 'Level 1', 0),
(54, 'ghhjg', 'Level 2', 18),
(55, 'jkhkj', 'Level 1', 0),
(56, 'jkhkj', 'Level 1', 0),
(57, 'dkjlkj', 'level_name', 0),
(58, 'ddd', 'level_name', 0),
(59, 'hjjk', 'level_name', 0),
(60, 'sjkhjk', 'Level 1', 0),
(61, 'shjkjh', 'level_name', 0),
(62, 'jkhkj', 'level_name', 0),
(63, 'djhjk', 'Level 2', 18),
(64, 'ejujhjk', 'Level 2', 18),
(65, 'djhkj', 'Level 2', 18),
(66, 'djhkj', 'Level 2', 18),
(67, 'dkj', 'Level 2', 18),
(68, 'dm,m', 'Level 1', 0),
(69, 'djh', 'Level 2', 18),
(70, 'jkhk', 'Level 1', 12),
(71, 'djhjk', 'Level 2', 18),
(72, 'dhj', 'level_name', 0);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--
-- Creation: Oct 30, 2018 at 01:07 PM
--

CREATE TABLE `questions` (
  `question_name` text NOT NULL,
  `answer1` varchar(250) NOT NULL,
  `answer2` varchar(250) NOT NULL,
  `answer3` varchar(250) NOT NULL,
  `answer4` varchar(250) NOT NULL,
  `answer` varchar(250) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_name`, `answer1`, `answer2`, `answer3`, `answer4`, `answer`, `id`) VALUES
('Who is the fastest to get to 10,000 ODI runs?', 'Sachin', 'Ganguly', 'Kohli', 'Matthew Hayden', '3', 4),
('Which year did Afghanistan gain their test status?', '2018', '2014', '2017', '2020', '1', 3),
('Which batsman scored the 2nd highest test \r\ninternational individual score?', 'Rohit Sharma', 'Brian Lara', 'Sachin Tendulkar', 'Matthew Hayden', '4', 1),
('Which batsman scored the fastest 1000 T20I runs?', 'Virat Kohli', 'Shane Watson', 'Babar Azam', 'Chris Gayle', '3', 2),
('Which non-Indian batsman has scored 3 T20I hundreds?', 'Colin Munro', 'Chris Gayle', 'AB De Villiers', 'Shahid Afridi', '1', 5),
('Where did England score their highest ODI score against Australia?', 'Southampton', 'Nottingham', 'Melbourne', 'Cardiff', '2', 6),
('Which batsman hit 6 fours in a world cup game?', 'Ramnaresh Sarwan', 'Tilakaratne Dilshan', 'Sanath Jayasuriya', 'Yuvraj Singh', '2', 7),
('When was the last time India won a test series against South Africa in South Africa?', '2018', '2004', '1992', '2006', '3', 8),
('Which among the following bowlers have not taken a wicket in their first ball of ODI career?', 'Brett Lee', 'Bhuvneshwar Kumar', 'Kevin O\'Brein', 'Keemo Paul', '1', 9),
('Which New Zealander is the first bowler to take a T20I wicket of his first ball?', 'Daniel Vettori', 'Shane Bond', 'Lockie Ferguson', 'Matt Henry', '3', 9),
('Who is the highest run scorer in T20I?', 'Virat Kohli', 'Shoaib Malik', 'Brendon Mcculum', 'David Warner', '3', 10),
('Who is the highest run-getter for India in T20Is?', 'Sachin Tendulkar', 'Rohit Sharma', 'Virat Kohli', 'Virender Sehwag', '2', 11),
('Which team have succesfully defended the lowest total(96) in T20I?', 'India', 'Australia', 'Pakistan', 'West Indies', '4', 12),
('Which Englishman has scored the most number of ODI runs since 2016?', 'Jos Buttler', 'Johnny Bairstow', 'Joe Root', 'Eoin Morgan', '3', 13),
('Which Indian player has hit the highest number of sixes in ODI?', 'Rohit Sharma', 'Virat Kohli', 'Hardik Pandya', 'MS Dhoni', '4', 14),
('Which West Indian player has registered the fastest ODI century?', 'Chris Gayle', 'Brian Lara', 'Shimron Hetmyer', 'Carlos Brathwaite', '2', 15),
('Which batsman hit 4 consecutive sixes against Ben Stokes in the 2016 World T20 final?', 'Marlon Samuels', 'Darren Sammy', 'Carlos Brathwaite', 'Keiron Pollard', '3', 16),
('Among the current South African team,which player has scored the highest test individual score?', 'AB De Villiers', 'Hashim Amla', 'Dean Elgar', 'Aiden Markram', '3', 17),
('Where did Rohit Sharma score his 3rd T20I hundred?', 'Canberra', 'Lucknow', 'Bristol', 'Barbados', '3', 18),
('Who is the highest T20 run-getter for Australia?', 'David Warner', 'Steve Smith', 'Aaron Finch', 'Tim Paine', '3', 19),
('Among the following West Indies batsmen, who has scored the highest T20 individual score?', 'Chris Gayle', 'Shai Hope', 'Jason Holder', 'Kraigg Braithwaite', '1', 20),
('What is the highest number of runs scored in an over?', '36', '90', '77', '38', '3', 21),
('Which batsman has scored the highest T20I runs?', 'Chris Gayle', 'Rohit Sharma', 'Kusal Perera', 'Aaron Finch', '4', 22);

-- --------------------------------------------------------

--
-- Table structure for table `result`
--
-- Creation: Oct 30, 2018 at 01:30 PM
--

CREATE TABLE `result` (
  `sixes` int(5) NOT NULL,
  `fours` int(5) NOT NULL,
  `wickets` int(5) NOT NULL,
  `wickets_entry` text NOT NULL,
  `tot_score` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`sixes`, `fours`, `wickets`, `wickets_entry`, `tot_score`) VALUES
(1, 0, 1, '', 6),
(1, 0, 2, '', 6),
(1, 0, 2, '', 6),
(2, 0, 2, '', 12),
(3, 0, 1, '', 18),
(5, 0, 0, '', 30),
(1, 0, 4, '', 6),
(3, 0, 2, '', 18),
(4, 0, 1, '', 24),
(3, 0, 2, '', 18),
(0, 0, 5, '', 0),
(1, 0, 4, '', 6),
(4, 0, 1, '', 24),
(5, 0, 1, '', 30),
(5, 0, 0, '', 30),
(4, 0, 1, '', 24),
(3, 0, 2, '', 18),
(1, 0, 5, '', 6),
(5, 0, 0, '', 30),
(4, 0, 1, '', 24),
(5, 0, 0, '', 30),
(5, 0, 0, '', 30),
(4, 0, 1, '', 24),
(3, 0, 2, '', 18),
(3, 0, 2, '', 18),
(3, 0, 2, '', 18),
(3, 0, 2, '', 18),
(3, 0, 2, '', 18),
(3, 0, 2, '', 18),
(3, 0, 2, '', 18),
(2, 0, 3, '', 12),
(3, 0, 2, '', 18);

-- --------------------------------------------------------

--
-- Table structure for table `score`
--
-- Creation: Oct 30, 2018 at 01:29 PM
--

CREATE TABLE `score` (
  `level_name` varchar(20) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `score` int(10) NOT NULL,
  `fours` int(5) NOT NULL,
  `sixes` int(5) NOT NULL,
  `wickets` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `score`
--

INSERT INTO `score` (`level_name`, `user_name`, `score`, `fours`, `sixes`, `wickets`) VALUES
('Level 1', 'mkjhkj', 6, 0, 1, 1),
('Level 1', 'fnjjh', 6, 0, 1, 2),
('Level 2', 'jhkjhk', 6, 0, 1, 2),
('Level 1', 'dhjkhk', 12, 0, 2, 2),
('Level 2', 'khlkhlkh', 18, 0, 3, 1),
('Level 2', 'shjkjhk', 30, 0, 5, 0),
('Level 1', 'djhkjh', 6, 0, 1, 4),
('Level 2', 'jhkjhk', 18, 0, 3, 2),
('Level 2', 'dhkjhk', 24, 0, 4, 1),
('Level 2', 'dklk', 18, 0, 3, 2),
('Level 1', 'slkjk', 0, 0, 0, 5),
('Level 1', 'ekhjk', 6, 0, 1, 4),
('Level 3', 'hjkjhkj', 24, 0, 4, 1),
('Level 3', 'hjkjhkj', 30, 0, 5, 1),
('Level 3', 'atul', 30, 0, 5, 0),
('Level 3', 'atul', 24, 0, 4, 1),
('Level 2', 'moyes', 18, 0, 3, 2),
('Level 2', 'moyes', 6, 0, 1, 5),
('Level 4', 'atul chandran', 30, 0, 5, 0),
('Level 4', 'atul chandran', 24, 0, 4, 1),
('Level 4', 'atul chandran', 30, 0, 5, 0),
('Level 4', 'Rohit', 30, 0, 5, 0),
('Level 4', 'Rohit', 24, 0, 4, 1),
('Level 4', 'Rohit', 18, 0, 3, 2),
('Level 4', 'Rohit', 18, 0, 3, 2),
('Level 2', 'ghhjg', 18, 0, 3, 2),
('Level 2', 'ejujhjk', 18, 0, 3, 2),
('Level 2', 'djhkj', 18, 0, 3, 2),
('Level 2', 'dkj', 18, 0, 3, 2),
('Level 2', 'djh', 18, 0, 3, 2),
('Level 1', 'jkhk', 18, 0, 3, 2),
('Level 1', 'jkhk', 12, 0, 2, 3),
('Level 2', 'djhjk', 18, 0, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Creation: Oct 30, 2018 at 01:26 PM
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_entry_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `user_mail_id` varchar(40) NOT NULL,
  `score` int(11) NOT NULL,
  `wicket` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `user_entry_time`, `user_mail_id`, `score`, `wicket`) VALUES
(10, 'hjjh', '0000-00-00 00:00:00', 'yuyu', 0, NULL),
(11, 'hjjh', '0000-00-00 00:00:00', 'hyjhj', 0, NULL),
(12, 'ytggh', '0000-00-00 00:00:00', 'gh', 0, NULL),
(13, 'ghgh', '0000-00-00 00:00:00', 'hjj', 0, NULL),
(14, 'fff', '0000-00-00 00:00:00', 'dff', 0, NULL),
(15, 'jhjh', '0000-00-00 00:00:00', 'uyug', 0, NULL),
(16, 'hbjhj', '0000-00-00 00:00:00', 'tyy]', 0, NULL),
(17, 'jhkjhk', '0000-00-00 00:00:00', 'iuyiuy', 24, 4),
(18, 'jhjkj', '0000-00-00 00:00:00', 'yiuyu', 0, NULL),
(19, 'jhkjh', '0000-00-00 00:00:00', 'kjhyjk', 0, NULL),
(20, 'jkhkjh', '0000-00-00 00:00:00', 'iuyi', 0, NULL),
(21, 'gjhjjhk', '0000-00-00 00:00:00', 'y', 0, NULL),
(22, 'mkjhkj', '0000-00-00 00:00:00', 'hjkj', 6, 1),
(23, 'ffdf', '0000-00-00 00:00:00', 'fkjk', 0, NULL),
(24, 'fnjjh', '0000-00-00 00:00:00', 'jhjh', 6, 2),
(25, 'dddd', '0000-00-00 00:00:00', 'dww', 0, NULL),
(26, ',mwkjk', '0000-00-00 00:00:00', 'kjk', 0, NULL),
(27, 'jkhjkKLJLKJ', '0000-00-00 00:00:00', 'KLLK', 0, NULL),
(28, 'jhkjhk', '0000-00-00 00:00:00', 'jgjgj', 24, 4),
(29, 'djhkjh', '0000-00-00 00:00:00', 'kjhkjhk', 6, 4),
(30, 'djd', '0000-00-00 00:00:00', 'jhkjhk', 0, NULL),
(31, 'dhjkhk', '0000-00-00 00:00:00', 'jhkhk', 12, 2),
(32, 'djkhjkh', '0000-00-00 00:00:00', 'jkhkjh', 0, NULL),
(33, 'khlkhlkh', '0000-00-00 00:00:00', 'klhljhk', 18, 1),
(34, 'dhkjhk', '0000-00-00 00:00:00', 'jhkj', 24, 1),
(35, 'dhkjhkj', '0000-00-00 00:00:00', 'hkjhk', 0, NULL),
(36, 'shjkjhk', '0000-00-00 00:00:00', 'hkjhk', 30, 0),
(37, 'djhkjhk', '0000-00-00 00:00:00', 'jhkjh', 0, NULL),
(38, 'djhkjh', '0000-00-00 00:00:00', 'kjhjk', 6, 4),
(39, 'fjlkjl', '0000-00-00 00:00:00', 'kjlkj', 0, NULL),
(40, 'jhkjhk', '0000-00-00 00:00:00', 'hkjhk', 24, 4),
(41, 'dhkjhk', '0000-00-00 00:00:00', 'jhkjhk', 24, 1),
(42, 'dkjk', '0000-00-00 00:00:00', 'lkjlk', 0, NULL),
(43, 'dkl', '0000-00-00 00:00:00', '', 0, NULL),
(44, 'kjjlkj', '0000-00-00 00:00:00', 'jklk', 0, NULL),
(45, 'sjlk', '0000-00-00 00:00:00', 'jlkj', 0, NULL),
(46, 'dklk', '0000-00-00 00:00:00', 'jkl', 18, 2),
(47, 'dklk', '0000-00-00 00:00:00', 'jkl', 18, 2),
(48, 'hjkjhk', '0000-00-00 00:00:00', 'jhkj', 0, NULL),
(49, 'slkjk', '0000-00-00 00:00:00', 'kjlj', 0, 5),
(50, 'ekhjk', '0000-00-00 00:00:00', 'hkj', 6, 4),
(51, 'djhkj', '2018-11-06 16:31:40', 'hkj', 18, 2),
(52, 'hjkjhkj', '0000-00-00 00:00:00', 'hkjhk', 54, 2),
(53, 'atul', '0000-00-00 00:00:00', 'ekyu', 54, 1),
(54, 'atul', '0000-00-00 00:00:00', 'hjkdj', 54, 1),
(55, 'moyes', '2018-11-06 10:02:25', 'yiuyiuy', 24, 7),
(56, 'moyes', '2018-11-06 10:02:25', 'iytu', 24, 7),
(57, 'moyes', '2018-11-06 10:02:25', 'yuiyi', 24, 7),
(58, 'atul chandran', '2018-11-06 14:21:32', '789987', 84, 1),
(59, 'Rohit', '2018-11-06 14:42:20', 'dhkjk', 90, 5),
(60, 'dkljkl', '0000-00-00 00:00:00', 'kjl', 0, NULL),
(61, 'ghhjg', '2018-11-06 14:54:30', 'jyi', 18, 2),
(62, 'jkhkj', '0000-00-00 00:00:00', 'kljlk', 0, NULL),
(63, 'jkhkj', '0000-00-00 00:00:00', 'kljlk', 0, NULL),
(64, 'dkjlkj', '0000-00-00 00:00:00', 'lkj', 0, NULL),
(65, 'ddd', '0000-00-00 00:00:00', 'jkj', 0, NULL),
(66, 'hjjk', '0000-00-00 00:00:00', 'kjhkj', 0, NULL),
(67, 'sjkhjk', '0000-00-00 00:00:00', 'hk', 0, NULL),
(68, 'shjkjh', '0000-00-00 00:00:00', 'jh', 0, NULL),
(69, 'jkhkj', '0000-00-00 00:00:00', 'hjk', 0, NULL),
(70, 'djhjk', '2018-11-06 16:35:22', '', 18, 2),
(71, 'ejujhjk', '2018-11-06 16:30:13', 'jd', 18, 2),
(72, 'djhkj', '2018-11-06 16:31:40', 'h', 18, 2),
(73, 'djhkj', '2018-11-06 16:31:40', 'hk', 18, 2),
(74, 'dkj', '2018-11-06 16:32:31', '', 18, 2),
(75, 'dm,m', '0000-00-00 00:00:00', 'k', 0, NULL),
(76, 'djh', '2018-11-06 16:33:01', 'hj', 18, 2),
(77, 'jkhk', '2018-11-06 16:35:05', 'jhk', 30, 5),
(78, 'djhjk', '2018-11-06 16:35:22', 'hk', 18, 2),
(79, 'dhj', '0000-00-00 00:00:00', 'hj', 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD KEY `level_ibfk_1` (`user_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_name` (`user_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `level`
--
ALTER TABLE `level`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
