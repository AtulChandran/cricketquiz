<?php
session_start();

?>
<?php 
require 'config.php';
global $con;
global $con1;
global $final_res;
if(!empty( $_SESSION['name'] && !empty( $_POST ) )){
    
    $sixes=0;
	$fours=0;
    $wrong_answer=0;
    $unanswered=0;
    $final_res=0;
	$wickets=0;	
     
   $keys = array_keys( $_POST );
   $order = join(",", $keys );
   
   
   
   $response = mysqli_query($con, "select id,answer from questions where id IN($order) ORDER BY FIELD(id,$order)")   or die(mysqli_error($con));
   
   while($result=mysqli_fetch_assoc($response)){
       if($result['answer']==$_POST[$result['id']]){
               $sixes++;
			   $final_res=$sixes*6;
           }else if($_POST[$result['id']]==5){
               $unanswered++;
           }
           else{
               $wrong_answer++;
           }
   }
   $name = $_SESSION['name'];  
   
   mysqli_query($con, "update users set score='$final_res' where user_name='$name'");
   mysqli_query($con, "update level set score='$final_res' where user_name='$name'");
   mysqli_query($con, "update level set level_name='Level 4' where user_name='$name'");
	
?>

<html>
<head>
  <meta charset="UTF-8">
  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <link rel="stylesheet" href="css/finish.css">

  
</head>

<body>
  <div class="wrapper">
    <div class="modal modal--congratulations">
        <div class="modal-top">
            <img class="modal-icon u-imgResponsive" src="trophy.png" alt="Trophy" />
            <div class="modal-header">Congratulations</div>
			<?php mysqli_query($con, "INSERT INTO score (user_name,level_name,score,fours,sixes,wickets) VALUES ('$name','Level 3','$final_res','$fours','$sixes','$wickets')") or die(mysqli_error( $con ));?>						

			<?php $six=mysqli_query($con,"select sum(sixes) from score where user_name='$name'");

					   $finalsix = mysqli_fetch_row($six);?>
					   <?php $result=mysqli_query($con,"select sum(score) from score where user_name='$name'");
							  $six=mysqli_query($con,"select sum(sixes) from score where user_name='$name'");
							  $wicket=mysqli_query($con,"select sum(wickets) from score where user_name='$name'");
							  
							$finalscore = mysqli_fetch_row($result);
							$finalwicket = mysqli_fetch_row($wicket);
						?>
						<?php  mysqli_query($con, "update users set score='$finalscore[0]' where user_name='$name'");?>                    
<?php  mysqli_query($con, "update users set wicket='$finalwicket[0]' where user_name='$name'");?>
            <div class="modal-subheader"><p>Score is : <span class="answer"><?php echo "$finalscore[0]/$finalwicket[0]"; ?></span></p></div>
        </div>
		
					   
						<?php $wickets=$wrong_answer+$unanswered;?>
						<?php mysqli_query($con, "INSERT INTO score (user_name,level_name,score,fours,sixes,wickets) VALUES ('$name','Level 4','$final_res','$fours','$sixes','$wickets')") or die(mysqli_error( $con ));?>						
						
					   
        <div class="modal-bottom">
		<!--<button class="modal-btn u-btn u-btn--share">Share</button>-->
		<a href="<?php echo BASE_PATH.'index.html';?>" <button class='modal-btn u-btn u-btn--share'>Start Again</button></a>
            
            
        </div>
    </div>
</div>
</body>
</html>
<?php }else{
    
 header( 'Location: '.BASE_PATH ) ;
      
}?>